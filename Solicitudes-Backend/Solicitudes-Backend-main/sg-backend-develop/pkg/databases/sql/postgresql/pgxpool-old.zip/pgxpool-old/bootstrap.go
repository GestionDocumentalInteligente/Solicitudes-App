package sdkpostgresql

import (
	"github.com/spf13/viper"

	defs "github.com/teamcubation/sg-backend/pkg/databases/sql/postgresql/pgxpool/defs"
)

func Bootstrap() (defs.Repository, error) {
	config := newConfig(
		viper.GetString("POSTGRES_USERNAME"),
		viper.GetString("POSTGRES_PASSWORD"),
		viper.GetString("POSTGRES_HOST"),
		viper.GetString("POSTGRES_PORT"),
		viper.GetString("POSTGRES_DB"),
	)

	if err := config.Validate(); err != nil {
		return nil, err
	}

	return newRepository(config)
}
